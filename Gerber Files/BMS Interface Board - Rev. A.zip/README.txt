*****************************************************************************
Project Name
*****************************************************************************

BMS Interface Board - Rev. A

*****************************************************************************
Contact & Shipping Information
*****************************************************************************

Name:	 	Felix van Oost
Phone:		+1 (778) 919-2072
E-Mail:		felix.vanoost@live.com

Address:	2356 Main Mall, MCLD 112B
		RT
		Vancouver BC, V6T 1Z4
		Canada

*****************************************************************************
Fabrication Information
*****************************************************************************

Quantity:		1
Board Material:		FR4
Board Thickness:	0.062"
# of Layers:		2
Copper Weight:		1oz
Surface Finish:		Lead-Free HASL
Solder Mask:		Green
Silkscreen:		White
Board Dimensions:	76mm x 80mm

*****************************************************************************
Aditional Notes	 
*****************************************************************************

None

*****************************************************************************
Layers
*****************************************************************************
	
Board Outline:		BMS Interface Board.GM1
Top Silkscreen:		BMS Interface Board.GTO
Top Solder Mask:	BMS Interface Board.GTS
Top Layer:		BMS Interface Board.GTL
Bottom Silkscreen:	BMS Interface Board.GBO
Bottom Solder Mask:	BMS Interface Board.GBS
Bottom Layer:		BMS Interface Board.GBL

NC Drill:		BMS Interface Board.txt	